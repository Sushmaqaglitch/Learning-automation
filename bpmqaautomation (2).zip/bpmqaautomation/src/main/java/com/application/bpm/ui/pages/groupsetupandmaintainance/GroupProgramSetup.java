package com.application.bpm.ui.pages.groupsetupandmaintainance;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;

public class GroupProgramSetup extends UIActions {
    private static By link_GroupProgramSetup = By.id("programSearch");
    private static By text_GroupNumber = By.id("groupNumber");
    private static By view_EditLink = By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[2]/a");
    private static By printer_FriendlyLink = By.xpath("//*[@id=\"content\"]/table/tbody/tr/td/table[2]/tbody/tr/td/table/tbody/tr/td[1]/div/table[2]/tbody/tr[4]/th/a");


    public static void userPerformGroupSetup() {
        clickOnElement(link_GroupProgramSetup);

    }

    public static void userPerformGroupNumber() {
        enterText(text_GroupNumber, "5032");
//        clickOnElement(button_Search);

    }

    public static void userPerformViewEditLink() {
        clickOnElement(view_EditLink);
    }

    public static void userPerformPrinterFriendlyLink() {
        clickOnElement(printer_FriendlyLink);
    }
}