package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;
public class MemberContractHistory extends UIActions {
    private static By link_MemberContractHistory = By.xpath("//*[@id=\"memberContractHistory\"]");
    private static By text_Memberid = By.id("memberID");

    public static void clickOnMemberContractHistory() {
        clickOnElement(link_MemberContractHistory);
        enterText(text_Memberid, "10108548");

    }
}
