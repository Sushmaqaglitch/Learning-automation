package com.application.bpm.ui.pages.groupsetupandmaintainance;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;
public class ReProcessActivities extends UIActions {
    private static By link_ReProcessActivity = By.name("filteredActivities");
    private static By textBox_MemberId = By.name("memberID");
    private static By textBox_TransactionDate = By.name("insertDate");
    private static By textBox_ActivityId = By.xpath("//select[@id='activityID']/option[@value='16041428']");
    private static By dropDown_GroupName=By.id("groupID");
    private static By button_Complete = By.xpath("//input[@value='Mark Completes']");
    private static By text_NoOfActivitiesReProcessed = By.xpath("//li[contains(text(), ' Activities have been marked for re-processing')]");

    public static void UserPerformReProcessActivity() {
        clickOnElement(link_ReProcessActivity);
    }

    public static void enterTheMemberID(String Message) {
        enterText(textBox_MemberId, "01209833");
        enterText(textBox_TransactionDate, "01/01/2024");
        clickOnElement(textBox_ActivityId);
        clickOnElement(button_Complete);
//        By  NoOfActivitiesReProcessed = driver.findElement(By.xpath("//li[contains(text(),'+mssage+')]"));

        String message = getText(text_NoOfActivitiesReProcessed);
        if (message.contains(Message)) {
            System.out.println("Message displayed as " + message);
        } else {
            System.out.println("Message not matched");
        }

    }

    public static void UserPerformMemberid() {
        clickOnElement(textBox_MemberId);
        enterText(textBox_MemberId, "01209833");

    }

    public static void UserPerformTransactionAfrerDate() {
        clickOnElement(textBox_TransactionDate);
        enterText(textBox_TransactionDate, "01/01/2024");
    }

    public static void UserPerformActivityName() {
        selectDropDownByText(textBox_ActivityId,"10,000 Steps (R) Program");
}

    public static void UserPerformGroupName() {
        selectDropDownByText(dropDown_GroupName,"28844 - 0906116 BC LIMITED");
}}