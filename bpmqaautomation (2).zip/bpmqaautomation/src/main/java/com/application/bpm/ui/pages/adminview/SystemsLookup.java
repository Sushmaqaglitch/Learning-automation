package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;
public class SystemsLookup extends UIActions {
    private static By link_SystemsLookup = By.id("showSystemsLookup");
    private static By text_SystemValue = By.id("systemValue");

    public static void clickOnSystemsLookup() {
        clickOnElement(link_SystemsLookup);
    }

    public static void userPerformSystemsValue() {
        selectDropDownByText(text_SystemValue, "Activity Definitions");

    }
}