package com.application.bpm.ui.pages.groupsetupandmaintainance;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;
public class BatchJobs extends UIActions {

    private static By link_BatchJobs = By.id("batchJobs");
    private static By button_DeleteParticipant = By.name("deleteTermedParticipants");
    private static By button_ContractReconciliation = By.name("contractReconciliation");
    private static By button_MemberShipFeed = By.name("membershipFeed");
    private static By button_CdhpHraFeed = By.name("hraFeed");
    private static By button_EmployerGroupBaseLineSetup = By.name("employerGroupBaselineSetup");
    private static By button_EmployerGroupSiteSetup = By.name("employerGroupSiteSetup");
    private static By button_PendingActivities = By.name("pendingActivities");
    private static By button_MembershipUpdate = By.name("membershipUpdate");

//    private static By button_DeleteTermedParticipants=By.name("deleteTermedParticipants");

    public static void userNavigateToBatchJobs() {
        clickOnElement(link_BatchJobs);
    }

    public static void userRunDeleteTermedParticipants() {
        clickOnElement(button_DeleteParticipant);
        switchToAlertAndAccept();
        switchToAlertAndAccept();
    }

    public static void userRunContractReconciliation() {
        clickOnElement(button_ContractReconciliation);
        switchToAlertAndAccept();
        switchToAlertAndAccept();

    }

    public static void userRunMemberShipFeed() {
        clickOnElement(button_MemberShipFeed);
        switchToAlertAndAccept();
        switchToAlertAndAccept();
    }

    public static void userRunCdhpHraFeed() {
        clickOnElement(button_CdhpHraFeed);
        switchToAlertAndAccept();
        switchToAlertAndAccept();
    }

    public static void userRunemployerGroupBaselineSetup() {
        clickOnElement(button_EmployerGroupBaseLineSetup);
        switchToAlertAndAccept();
        switchToAlertAndAccept();
    }

    public static void userRunEmployerGroupSiteSetup() {
        clickOnElement(button_EmployerGroupSiteSetup);
        switchToAlertAndAccept();
        switchToAlertAndAccept();
    }

    public static void userRunPendingActivities() {
        clickOnElement(button_PendingActivities);
        switchToAlertAndAccept();
        switchToAlertAndAccept();
    }

    public static void userRunMembershipUpdateBatchjob() {
        clickOnElement(button_MembershipUpdate);
        switchToAlertAndAccept();
//        switchToAlertAndAccept();
    }
}

