package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;
public class MemberEligibilityHistory extends UIActions {
    private static By link_MemberEligibilityHistory = By.id("baselineHistory");
    private static By text_MemberId = By.name("memberID");
    private static By button_Search = By.className("button");

    private static By button_Back = By.name("back");
    private static By label_MemberName = By.xpath("//td[contains(text(),'Member Name')]");

    public static void clickOnMemberEligibilityHistory() {
        clickOnElement(link_MemberEligibilityHistory);
    }

    public static void userPerformMemberId() {
        clickOnElement(text_MemberId);
        enterText(text_MemberId, "10108548");
    }

    public static void userPerformSearchButton() {
        clickOnElement(button_Search);

    }

    public static void userPerformBackButton() {
        clickOnElement(button_Back);
    }

    public static void validatemembernamefrommembereligibilityhistory(String membername) {
        String MemberName = getText(label_MemberName);
        if (membername.equalsIgnoreCase(MemberName)) {
            System.out.println(membername);
        }
    }

}
