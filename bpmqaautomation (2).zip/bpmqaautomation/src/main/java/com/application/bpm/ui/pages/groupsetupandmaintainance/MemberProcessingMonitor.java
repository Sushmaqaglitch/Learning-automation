package com.application.bpm.ui.pages.groupsetupandmaintainance;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;

public class MemberProcessingMonitor extends UIActions {

    private static By link_MemberProcessingMonitor = By.id("memberProcessingMonitor");
    private static By button_Refresh = By.name("refresh");

    public static void userPerformMemberProcessingMonitor() {
        clickOnElement(link_MemberProcessingMonitor);
    }


    public static void userPerformRefreshButton() {
        clickOnElement(button_Refresh);
    }
}
