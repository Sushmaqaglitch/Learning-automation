package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;
public class PersonRewardCardFulfillmentLookup extends UIActions {
    private static By link_PersonRewardCardFulfillmentLookup = By.xpath("//*[@id=\"rewardCardFulfillmentHistory\"]");
    private static By text_GroupNumber = By.id("groupNumber");
    private static By dropdown_RewardCard = By.id("rewardCardID");

    public static void userPerformPersonRewardCardFulfillmentLookup() {
        clickOnElement(link_PersonRewardCardFulfillmentLookup);
    }

    public static void userPerformGroupNumber() {
        enterText(text_GroupNumber, "3052");
    }

    public static void userPerformRewardCard() {
        clickOnElement(dropdown_RewardCard);
        selectDropDownByText(dropdown_RewardCard, "HealthPartners PrePaid MasterCard");

    }
}
