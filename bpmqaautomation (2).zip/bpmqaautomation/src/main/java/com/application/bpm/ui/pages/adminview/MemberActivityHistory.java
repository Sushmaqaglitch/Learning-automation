package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;

public class MemberActivityHistory extends UIActions {
    private static By textBox_MemberId = By.name("memberID");
    private static By textBox_QualificationStartDate = By.name("qualificationStartDate");
    private static By button_Search = By.name("search");
    private static By link_MemberActivityHistory = By.name("memberActivityHistory");
    public static void clickOnMemberActivityHistory() {
        clickOnElement(link_MemberActivityHistory);
    }

    public static void userPerformMemberActivityHistory() {

        enterText(textBox_MemberId, "1234");
        selectDropDownByText(textBox_QualificationStartDate, "04/01/2022");
        clickOnElement(button_Search);
    }


//    public static void userPerformMemberActivityHistory() {
//        enterText(textBox_MemberId, MemberId);
//        enterText(textBox_QualificationStartDate, QualificationStartDate);

}

