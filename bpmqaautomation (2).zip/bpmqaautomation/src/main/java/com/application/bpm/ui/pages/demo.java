package com.application.bpm.ui.pages;

import com.application.bpm.ui.pages.groupsetupandmaintainance.BatchJobs;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static com.application.bpm.ui.pages.login.LogIn.userLoginToBPMApplication;
public class demo extends BatchJobs {
    public static void main(String[] args) throws Exception {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
//        driver.get("https://bpmtest.healthpartners.com/bpm-admin/bpmadminindex.do");
//        driver.findElement(By.name("j_username")).sendKeys("h1115");
//        By button_Go = By.name("go");
//        By link_home = By.linkText("Home");
//        driver.manage().window().maximize();
        userLoginToBPMApplication();
        userNavigateToBatchJobs();
        userRunMemberShipFeed();
        System.out.println(switchToAlertAndGetText());
        switchToAlertAndAccept();
        switchToAlertAndDismiss();
//        By link_Action = By.linkText("Activity Incentive Contribution Status Lookup");
//        By dropDown_reportType = By.name("reportType");
//        clickOnElement(link_Action);
//        // dropdown related
//        // selectDropDownByText(dropDown_reportType,"PENDING (SYSTEM)");
//        //selectDropDownByIndex(dropDown_reportType,1);
//        selectDropDownByValue(dropDown_reportType, "PENDING (SYSTEM)");
//
//        System.out.println(getSelectedDropdownValue(dropDown_reportType));
//
//        System.out.println(getAllOptionsFromDropDown(dropDown_reportType));
        // right click , alll mouse and keyboard actions
//        Actions actions = new Actions(driver);
////        actions.contextClick().build().perform();
//        actions.sendKeys(Keys.TAB,Keys.TAB,Keys.ENTER).build().perform();
////        System.out.println(driver.findElement(link_home).isDisplayed());
////        actions.moveToElement(driver.findElement(link_home)).doubleClick().build().perform();
//
//        actions.doubleClick(driver.findElement(link_home)).build().perform();


    }

}


