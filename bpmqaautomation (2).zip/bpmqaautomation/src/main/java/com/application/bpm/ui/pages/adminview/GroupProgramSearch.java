package com.application.bpm.ui.pages.adminview;


import com.application.bpm.ui.base.UIActions;
import org.junit.Assert;
import org.openqa.selenium.By;

public class GroupProgramSearch extends UIActions {
    private static By textBox_GroupNumber = By.name("groupNumber");
    private static By textBox_GroupName = By.name("groupName");
    private static By button_Search = By.name("search");
    public static By button_CheckboxCopy = By.name("selectedSubgroups");
    public static By dropdown_ProgramType = By.name("businessProgramTypeName");
    public static By display_Message = By.xpath("//li[text()='Programs copied successfully.']");
    public static By view_Edit = By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[2]/a");
    public static By edit_Button = By.name("edit");
    public static By additional_Programinfo = By.id("additionalGroupProgramInfo");
    public static By save_AllSites = By.name("saveToAllSites");
    public static By saveToSelected_Sites = By.name("saveToSelected");
    public static By remove_Button = By.xpath("//a[text()='Remove']");
    public static By cancel_Button = By.name("cancelViewProgram");
    public static By view_Edit1 = By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[2]/td[2]/a");

    private static By text_Result = By.xpath("//td[contains(text(),'Results returned')]");
    public static By eligible_Activities = By.name("editActivities");
    public static By add_Button1 = By.xpath("//*[@id=\"programPackages\"]/tbody/tr[4]/td[1]/a");
    public static By save_Button = By.name("save");
    public static By add_Activity = By.xpath("//*[@id=\"tableAvailableActivities\"]/tbody/tr[22]/td[1]/a");
    public static By dropdown_IncentiveOverride = By.id("incentiveOverrideCodeIDs0");
    public static By message_Error = By.xpath("//div[@class='error']");
    private static By link_GroupProgramSearch = By.id("programSearch");
    private static By add_Button = By.name("addProgram");
    //    private static By group_Number =By.name("groupNumber");
    private static By search_Button = By.id("searchButton");
    private static By link_GroupNumber = By.xpath("//a[text()='5032']");
    private static By link_GroupStartDate = By.name("groupStartDate");
    private static By create_Program = By.id("createProgramButton");
    private static By dropdown_ProgramStatus = By.name("programStatusCodeID");
    private static By dropdown_ParticipationRequirement = By.name("familyParticipationRequirement");
    private static By button_Save = By.className("button");
    private static By button_Copy = By.xpath("//a[text()='Copy'][1]");
    private static By dropdown_SiteName = By.name("subgroupID");
    private static By button_Delete = By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[14]/a");
    private static By button_CopyToYear = By.name("copyToYear");
    private static By text_NewStartDate = By.name("groupStartDates");
    private static By check_Marks = By.name("editCheckmarks");
    private static By dropdown_ParticipationGroup = By.id("participationGroupIDs[0]");
    private static By button_Add = By.xpath("//*[@id=\"saveProgramCheckmarksForm\"]/table[6]/tbody/tr[92]/td[1]/a");
    private static By dropdown_IncentiveOption = By.id("programIncentiveOptionIDs[0]");
    private static By button_Save_Checkmark = By.name("save");
    private static By incentive_Option = By.name("editIncentives");
    private static By button_AddIncentive = By.xpath("//*[@id=\"incentiveOptions\"]/tbody/tr[1]/td[1]/a");
    private static By dropdown_IncentiveRule = By.name("incentiveRuleTypeCodeIDs[0]");
    private static By dropdown_DisplayStatus = By.name("programIncentiveOptionStatusIDs[0]");
    private static By dropdown_FulfillmentRouting = By.name("programIncentiveFulfillReqIDs[0]");
    private static By dropdown_IncentiveReport = By.name("programIncentiveReportNameIDs[0]");
    private static By dropdown_IncentedStatus = By.name("incentedStatusTypeCodeIDs[0]");
    private static By dropdown_IncentivePackageRule = By.name("packageRuleGroupIDs[0]");
    private static By dropdown_ParticipationGroupReq = By.name("participationGroupIDs[0]");
    private static By dropdown_DeliveryInfo = By.name("deliveryInfoIDs[0]");


    private static By button_SaveToAllSite = By.className("button");
    private static By button_SaveToSelectedSites = By.name("saveToSelectedSites");

    private static By button_Remove = By.xpath("//*[@id=\"tableProgramIncentives\"]/tbody/tr[1]/td[1]/a");
    private static By text_Add = By.xpath("//*[@id=\"tableProgramIncentives\"]/tbody/tr[8]/td[2]/a");
    private static By button_SaveToSelectSites = By.name("selectSites");
    private static By button_SaveToAllSite2 = By.name("saveToAllSites");
    private static By dropDown_ContributionTier = By.name("tierTypeID");
    private static By message = By.xpath("//samp[contains(text(),'ADD PROGRAM CONTRIBUTION GRID:')]");
    private static By dropDown_AssinedActivity = By.id("activityID");
    private static By dropDown_AssignedActivityType = By.id("activityTypeCodeID");
    private static By button_Add_BenefitContract = By.xpath("//*[@id=\"tableContributionIncentiveTier\"]/thead/tr[2]/td[4]/a");
    private static By dropDown_BenefitContractType = By.id("programBenefitContractTypeIDs[0]");
    private static By dropDown_Relationship = By.id("relationshipIDs[0]");
    private static By text_Amount = By.id("contributionAmounts[0]");
    private static By button_SaveContrubutionGrid = By.name("save");

    private static By auth_Code = By.name("editExtendedAuthCodes");
    private static By add_AuthCode = By.name("add");
    private static By text_AuthoCode = By.id("extendedAuthCodeNames[2]");
    private static By dropdown_AuthPromo = By.id("extendedAuthCodeTypeCodes[2]");
    private static By text_EffDate = By.id("effectiveDate2");
    private static By text_EndDate = By.id("endDate2");

    private static By button_SaveAuthcode = By.name("save");

    private static By link_remove_ContributionIncentivetier = By.xpath("//*[@id=\"tableContributionIncentiveTier\"]/tbody/tr/td[4]/a");
    private static By button_Download = By.name("download");
    private static By change_Log = By.name("editChangeLog");
    private static By change_Text = By.name("changeText");
    private static By button_Cancel = By.name("cancel");


    public static void clickOnGroupProgramSearch() {
        clickOnElement(link_GroupProgramSearch);
    }

    public static void userPerformGroupProgramSearch() {
//        enterText(textBox_GroupNumber, "3052");
        enterText(textBox_GroupNumber, "5032");
//        enterText(textBox_GroupNumber, "8749");
//        enterText(textBox_GroupName, "sushma");
        clickOnElement(search_Button);
    }

//    public static void userPerformGroupProgramSearch(String groupNumber, String grpName) {
//        enterText(textBox_GroupNumber, groupNumber);
//        enterText(textBox_GroupName, grpName);
//        clickOnElement(button_Search);

//    }

    public static void userPerformAddButton() {
        clickOnElement(add_Button);


//    }
//    public static void userPerformGroupNumber(){
//        clickOnElement(group_Number);
    }

    public static void userPerformSearchButton() {
        clickOnElement(search_Button);


    }

    public static void userPerformClickOnGroupNumber() {
        clickOnElement(link_GroupNumber);
    }

    public static void userPerformGroupStartDate() {
        clickOnElement(link_GroupStartDate);
        enterText(link_GroupStartDate, "01/26/2024");


    }

    public static void userPerformCreateProgram() {
        clickOnElement(create_Program);

    }

    public static void userPerformProgramStatus() {
        clickOnElement(dropdown_ProgramStatus);
        selectDropDownByText(dropdown_ProgramStatus, "Active Business Program");

    }

    public static void userPerformParticipationrequirement() {
        clickOnElement(dropdown_ParticipationRequirement);
        selectDropDownByText(dropdown_ParticipationRequirement, "All Members 18 and Older");

    }

    public static void userPerformSaveButton() {
        clickOnElement(button_Save);
    }

    public static void userPerformCopyButton() {
        clickOnElement(button_Copy);
    }

    public static void userPerformSiteName() {
        clickOnElement(dropdown_SiteName);
    }

    public static void userPerformDelete() {
        clickOnElement(button_Delete);
    }

    public static void userPerformCopytoYear() {
        clickOnElement(button_CopyToYear);
    }

    public static void userPerformNewStartDate() {
        clickOnElement(text_NewStartDate);
        enterText(text_NewStartDate, "10/26/2024");
    }

    public static void userPerformbutton_CheckboxCopy() {
        clickOnElement(button_CheckboxCopy);
    }

    public static void userPerformdropdown_ProgramType() {
        clickOnElement(dropdown_ProgramType);
        selectDropDownByText(dropdown_ProgramType, "ISR");
    }

    public static void addedRecordValidation() {
        getElementTextByAttribute(display_Message, "Programs copied successfully.");
        System.out.println(getText(display_Message));
    }

    public static void userPerformViewEdit() {
        clickOnElement(view_Edit);
    }

    public static void userPerformEdit() {
        clickOnElement(edit_Button);
    }

    public static void userEntertheTextApi() {
        enterText(additional_Programinfo, "Testing 26272");
    }

    public static void userPerformSavetoAllSites() {
        clickOnElement(save_AllSites);
    }

    public static void userPerformSavetoSelectedSites() {
        clickOnElement(saveToSelected_Sites);
    }

    public static void userPerformRemove() {
        clickOnElement(remove_Button);
    }

    public static void userPerformCancel() {
        clickOnElement(cancel_Button);
    }

    public static void userPerformViewEdit1() {
        clickOnElement(view_Edit1);
    }

    public static void userPerformEligibleActivities() {
        clickOnElement(eligible_Activities);
    }

    public static void userPerformClickOnAddButton() {
        clickOnElement(add_Button1);
    }

    public static void userPerformClickOnSaveButton() throws InterruptedException {
        Thread.sleep(2000);
        clickOnElement(save_Button);
//        switchToAlertAndAccept();

    }

    public static void userPerformClickOnAddActivity() {
        clickOnElement(add_Activity);

    }

    public static void userPerformIncentiveOverride() {
        clickOnElement(dropdown_IncentiveOverride);
        selectDropDownByText(dropdown_IncentiveOverride, "POST_ENROLLMENT");


    }

    public static void userValidateTheError() {
        String message = getText(message_Error);
        System.out.println(message);
        if (message.equalsIgnoreCase("Post Enrollment start date before program qualification end date.")) {
            System.out.println(message);
        }
    }

    public static void verifyGroupNameAndGroupNumberInProgramResultsGrid(String expectedGroupNumber, String
            expectedGrpName) {


        int totalNumberOfRows = Integer.parseInt(getText(text_Result).split("=")[1].trim());
        System.out.println("Numbers of records found :" + totalNumberOfRows);
        if (!expectedGroupNumber.isEmpty()) {
            for (int row = 2; row <= totalNumberOfRows + 1; row++) {
                String actualGroupNbr = getText(By.xpath("(//table[contains(@id,'table')]//tr)[" + row + "]/td[4]"));
                Assert.assertEquals("Group Number Not Matched", expectedGroupNumber, actualGroupNbr);
            }
        }
        if (!expectedGrpName.isEmpty()) {
            for (int row = 2; row <= totalNumberOfRows + 1; row++) {
                String actualGroupName = getText(By.xpath("(//table[contains(@id,'table')]//tr)[" + row + "]/td[3]"));
                Assert.assertEquals("Group Name Not Matched", expectedGrpName, actualGroupName);
            }
        }
    }

    public static void userPerformCheckmark() {
        clickOnElement(check_Marks);

    }

    public static void userPerformParticipationGroup() {
        clickOnElement(button_Add);
        clickOnElement(dropdown_ParticipationGroup);
        selectDropDownByText(dropdown_ParticipationGroup, "Health Plan Indicator");
        selectDropDownByText(dropdown_IncentiveOption, "EMPLOYER REWARD");

    }

    public static void userPerformAddCheckMark() {
        clickOnElement(button_Add);
    }

    public static void userPerformIncentiveOption() {
        selectDropDownByText(dropdown_ParticipationGroup, "Health Plan Indicator");
        selectDropDownByText(dropdown_IncentiveOption, "HRA CONTRIBUTION I");

    }

    public static void userPerformclickSave() {
        clickOnElement(button_Save_Checkmark);
        switchToAlertAndAccept();
    }


    public static void userPerformIncentiveOptionTab() {
        clickOnElement(incentive_Option);

    }

    public static void userPerformAddIncentives() {
        clickOnElement(button_AddIncentive);
    }

    public static void userPerformIncentiveRuleType() {
        selectDropDownByText(dropdown_IncentiveRule, "COMMUNICATED");
    }

    public static void userPerformDisplayStatus() {
        selectDropDownByText(dropdown_DisplayStatus, "HCSS");
    }

    public static void userPerformIncentiveFulfilmentRouting() {
        selectDropDownByText(dropdown_FulfillmentRouting, "SND_EMP_PORTAL");
    }

    public static void userPerformIncentiveReportName() {
        selectDropDownByText(dropdown_IncentiveReport, "HEALTH_DOLLARS");

    }

    public static void userPerformIncentedStatus() {
        selectDropDownByText(dropdown_IncentedStatus, "ACTIVITY_BASED");
    }

    public static void userPerformIncentivePackageRule() {
        selectDropDownByText(dropdown_IncentivePackageRule, "Default For All Packages");
    }

    public static void userPerformParticipationGroupReq() {
        selectDropDownByText(dropdown_ParticipationGroupReq, "Default for all participants");
    }

    public static void userPerformDeliveryInfo() {
        selectDropDownByText(dropdown_DeliveryInfo, "Employer Administered");
    }

    public static void userPerformSaveToAllSites() {
        clickOnElement(button_SaveToAllSite);
        switchToAlertAndAccept();
    }

    public static void userPerformSaveToSelectedSites() {
        clickOnElement(button_SaveToSelectedSites);
//        switchToAlertAndAccept();
    }

    public static void userPerformRemoveButton() {
        clickOnElement(button_Remove);
    }

    public static void userPerformclickSaveWithNoAlert() {
        clickOnElement(button_Save_Checkmark);

    }
//    public static void userPerformSavetoSelected() {
//        clickOnElement(button_SavetoSelectedSites);

    public static void userPerformAdd() {
//        Thread.sleep(2000);
//        waitForElementIsVisible(text_Add);
        clickOnElement(text_Add);
    }

    public static void userPerformSaveToSelectSites() {
        clickOnElement(button_SaveToSelectSites);
//        switchToAlertAndAccept();


    }

    public static void userPerformSaveToAllSite2() {
        clickOnElement(button_SaveToAllSite2);
//        switchToAlertAndAccept();

    }

    public static void userPerformContributionTier() {

        clickOnElement(dropDown_ContributionTier);
        waitForElementIsVisible(dropDown_ContributionTier);
        selectDropDownByValue(dropDown_ContributionTier, "21");
//        selectDropDownByText(dropDown_AssinedActivity,"Select");
        selectDropDownByText(dropDown_AssignedActivityType, "Health Screening");
    }

    public static void userAddBenefitContractContriAmt() throws InterruptedException {
        clickOnElement(button_Add_BenefitContract);
        Thread.sleep(2000);
        selectDropDownByValue(dropDown_BenefitContractType, "987");
        selectDropDownByText(dropDown_Relationship, "SELF");
        enterText(text_Amount, "2");

    }

    public static void userPerformSave() {
        clickOnElement(button_SaveContrubutionGrid);

    }

    public static void userPerformAuthCode() {
        clickOnElement(auth_Code);
    }

    public static void userPerformAddOrEditAuthCode() {
        clickOnElement(add_AuthCode);
    }

    public static void userPerformAuthCodeText() {
        enterText(text_AuthoCode, "SSHA2029");

    }

    public static void userPerformAuthOrPromo() {
        selectDropDownByText(dropdown_AuthPromo, "PM");

    }

    public static void userPerformEffDate() {
        enterText(text_EffDate, "11/20/2024");

    }

    public static void userPerformEndDate() {
        enterText(text_EndDate, "10/31/2025");


    }

    public static void userPerformSaveAuthCode() {
        clickOnElement(button_SaveAuthcode);

    }

    public static void userPerformRemoveContributionIncentiveTier() {
        clickOnElement(link_remove_ContributionIncentivetier);

    }

    public static void userPerformDownload() {
        clickOnElement(button_Download);

    }

    public static void userPerformClickOnChangeLog() {
        clickOnElement(change_Log);
    }

    public static void userPerformChangeText() {
        enterText(change_Text, "Automation");

    }

    public static void userPerformCancelButton() {
        clickOnElement(button_Cancel);

    }
}