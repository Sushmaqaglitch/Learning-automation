package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.junit.Assert;
import org.openqa.selenium.By;

public class GroupLookup extends UIActions {

    private static By textBox_GroupNumber = By.name("groupNumber");
    private static By textBox_GroupName = By.name("groupName");
    private static By button_Search = By.xpath("//input[@value='Search']");
    private static By link_GroupLookup = By.xpath("//a[@id='groupLookup']");
    private static By text_Result = By.xpath("//td[contains(text(),'Results returned')]");

    public static void clickOnGroupLookup() {
        clickOnElement(link_GroupLookup);
    }

    public static void userPerformGroupLookup() {
        enterText(textBox_GroupNumber, "5032");
//        enterText(textBox_GroupName, "sushma");
        clickOnElement(button_Search);

    }

    public static void userPerformGroupLookup(String groupNumber, String grpName) {
        enterText(textBox_GroupNumber, groupNumber);
        enterText(textBox_GroupName, grpName);
        clickOnElement(button_Search);
        Assert.assertTrue("Records Results Not Found", isElementDisplayed(text_Result));
    }

    public static void verifyGroupNameAndGroupNumberInResultGrid(String expectedGroupNumber, String expectedGrpName) {


        int totalNumberOfRows = Integer.parseInt(getText(text_Result).split("=")[1].trim());
        System.out.println("Numbers of records found :" + totalNumberOfRows);
        if (!expectedGroupNumber.isEmpty()) {
            for (int row = 2; row <= totalNumberOfRows + 1; row++) {
                String actualGroupNbr = getText(By.xpath("(//table[contains(@id,'table')]//tr)[" + row + "]/td[2]"));
                Assert.assertEquals("Group Number Not Matched", expectedGroupNumber, actualGroupNbr);
            }
        }
        if (!expectedGrpName.isEmpty()) {
            for (int row = 2; row <= totalNumberOfRows + 1; row++) {
                String actualGroupName = getText(By.xpath("(//table[contains(@id,'table')]//tr)[" + row + "]/td[3]"));
                Assert.assertEquals("Group Name Not Matched", expectedGrpName, actualGroupName);
            }
        }
    }
}
