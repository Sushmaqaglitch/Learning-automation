package com.application.bpm.ui.pages.groupsetupandmaintainance;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;

public class PersonEmployerActivityRecycleReview extends UIActions {
    private static By link_PersonEmployerActivityRecycle = By.id("personEmployerActivityRecycleSearch");

    private static By dropdown_RecycleStatus = By.id("recycleStatusId");

    private static By text_ReasonDescription=By.id("reason");
    private static By link_Button=By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[2]/a");
    public static void userPerformPersonEmployerActivityRecycle() {
        clickOnElement(link_PersonEmployerActivityRecycle);
    }
    public static void userPerformRecycleStatus() {
        clickOnElement(dropdown_RecycleStatus);
        selectDropDownByText(dropdown_RecycleStatus, "PROCESSED");
}
    public static void userPerformReasonDescription() {
        clickOnElement(text_ReasonDescription);
        enterText(text_ReasonDescription, "Person demographic match found.Activity created for person Testing is performed");

}
    public static void userPerformEdit() {
        clickOnElement(link_Button);
}}