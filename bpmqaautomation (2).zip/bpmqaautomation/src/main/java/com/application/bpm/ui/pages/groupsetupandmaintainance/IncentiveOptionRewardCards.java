package com.application.bpm.ui.pages.groupsetupandmaintainance;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;

public class IncentiveOptionRewardCards extends UIActions {

    private static By link_IncentiveOptionRCard = By.id("showIncentiveOptionRewardCards");
    private static By button_Add = By.name("add");
    private static By text_IncentiveOptionRewardName = By.id("incentiveOptionRewardCardName");
    private static By text_IncentiveOptionRewardDesc = By.id("incentiveOptionRewardCardDesc");
    private static By text_EffectiveDate = By.id("effectiveDate");
    private static By text_EndDate = By.id("endDate");

    private static By dropdown_RewardCard = By.id("rewardCardID");
    private static By dropdown_RewardCardFee = By.id("rewardCardFeeID");
    private static By dropdown_RewardCardEmbossedLine = By.id("rewardEmbossedLineID");
    private static By dropdown_RCcarrierMessage = By.id("rewardCarrierMessageID");
    private static By dropdown_RCTransMessage = By.id("rewardTransactionMessageID");
    private static By dropdown_RCclientContactInfo = By.name("rewardCardClientContactID");
    private static By button_Save = By.name("save");


    public static void userPerformIncentivesOptionRewardCard() {
        clickOnElement(link_IncentiveOptionRCard);


    }

    public static void userPerformAddbutton() {
        clickOnElement(button_Add);
    }

    public static void userPerformIncentiveOptionRewardName() {
        clickOnElement(text_IncentiveOptionRewardName);
        enterText(text_IncentiveOptionRewardName, "Testing");
    }

    public static void userPerformIncentiveOptionRewardDesc() {
        clickOnElement(text_IncentiveOptionRewardDesc);
        enterText(text_IncentiveOptionRewardDesc, "Testing Desc");

    }

    public static void userPerformEffectiveDate() {
        clickOnElement(text_EffectiveDate);
        enterText(text_EffectiveDate, "09/17/2024");

    }

    public static void userPerformEndDate() {
        clickOnElement(text_EndDate);
        enterText(text_EndDate, "09/17/2024");
    }

    public static void userPerformRewardCard() {
        clickOnElement(dropdown_RewardCard);
        selectDropDownByText(dropdown_RewardCard, "HealthPartners PrePaid MasterCard");
    }

    public static void userPerformRewardCardFee() {
        clickOnElement(dropdown_RewardCardFee);
        selectDropDownByText(dropdown_RewardCardFee, "HealthPartners - Default");
    }

    public static void userPerformRewardEmbossedLine() {
        clickOnElement(dropdown_RewardCardEmbossedLine);
        selectDropDownByText(dropdown_RewardCardEmbossedLine, "HealthPartners - Default");

    }

    public static void userPerformRCcarrierMessage() {
        clickOnElement(dropdown_RCcarrierMessage);
        selectDropDownByText(dropdown_RCcarrierMessage, "HealthPartners - Default");

    }

    public static void userPerformRCTransMessage() {
        clickOnElement(dropdown_RCTransMessage);
        selectDropDownByText(dropdown_RCTransMessage, "HealthPartners - Default");
    }

    public static void userPerformRCclientContactInfo() {
        clickOnElement(dropdown_RCclientContactInfo);
        selectDropDownByText(dropdown_RCclientContactInfo, "HealthPartners - Default");

    }

    public static void userPerformSave() {
        clickOnElement(button_Save);
    }
}