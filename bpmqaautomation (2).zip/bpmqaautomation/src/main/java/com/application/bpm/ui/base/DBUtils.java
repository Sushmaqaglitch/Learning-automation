package com.application.bpm.ui.base;

import java.sql.*;

public class DBUtils extends PropertyReader {
    public static String memberID = null;

    public static Connection connectToDB() throws SQLException, ClassNotFoundException {
        Connection con = DriverManager.getConnection(dbURL, dbUserName, dbPassword);
        Class.forName("oracle.jdbc.driver.OracleDriver");
        System.out.println("connected");
        return con;
    }

    public static int getTotalRowCount(String query) throws SQLException, ClassNotFoundException {
        Statement stmt = connectToDB().createStatement();
        ResultSet resultSet = stmt.executeQuery(sqlProperties.getProperty(query));
        resultSet.next();
        System.out.println(resultSet.getInt(1));
        return resultSet.getInt(1);
    }

    public static String getName(String query) throws SQLException, ClassNotFoundException {
        Statement stmt = connectToDB().createStatement();
        ResultSet resultSet = stmt.executeQuery(sqlProperties.getProperty(query));
        resultSet.next();
        System.out.println(resultSet.getString("REGISTRATION_ID"));
        return resultSet.getString("REGISTRATION_ID");


    }

    public static String getData() throws SQLException, ClassNotFoundException {
        String data = "select x.grp_id,\n" +
                "       x.empl_grp_no,\n" +
                "       x.empl_grp_nm,\n" +
                "       x.market_nm,\n" +
                "     --  x.biz_pgm_nm,\n" +
                "     --  x.biz_pgm_eff_dt,\n" +
                "     --  x.subgrp_id,\n" +
                "     --  x.empl_grp_site_id_no,\n" +
                "     --  x.rel_cd,\n" +
                "       --x.insert_date,\n" +
                "       x.census\n" +
                "       \n" +
                "from       \n" +
                "\n" +
                "(select --psl.prsn_id,\n" +
                "       pb.grp_id,\n" +
                "       egs.empl_grp_no,\n" +
                "       egs.empl_grp_nm,\n" +
                "      -- pb.biz_pgm_eff_dt,\n" +
                "       --01/02/2021 - Add Case statement to identify market\n" +
                "       Case \n" +
                "         when egs.empl_grp_no = '0060' OR egs.empl_grp_no = '0076' then 'MCARE'\n" +
                "         when egs.empl_grp_no = '4183' OR egs.empl_grp_no = '4190' then 'MCAID-INCENTED'  \n" +
                "         when egs.empl_grp_no = '4180' OR egs.empl_grp_no = '4182' OR egs.empl_grp_no = '4184' OR    \n" +
                "              egs.empl_grp_no = '4186' OR egs.empl_grp_no = '4187' OR egs.empl_grp_no = '4188' then 'MCAID-NON-INCENTED'\n" +
                "         --when egs.empl_grp_no = ('4180','4182','4184','4186','4187','4188') then 'MCAID-NO-INCENTED' \n" +
                "         --when biz_pgm.biz_pgm_tp_cd in (9) then 'EZ PLAN'\n" +
                "           else\n" +
                "             'LARGE-GROUP'\n" +
                "       End as market_nm, \n" +
                "          \n" +
                "    --   biz_pgm.biz_pgm_nm, \n" +
                "    --   pb.subgrp_id,\n" +
                "    --   egs.empl_grp_site_id_no,\n" +
                "    --   egs.empl_grp_site_nm,\n" +
                "    --   pb.rel_cd,\n" +
                "       --to_char(trunc(psl.insert_ts), 'MM/DD/YYYY') as insert_date,\n" +
                "       count(distinct psl.prsn_id) as census\n" +
                "\n" +
                " from bpm.processing_status_log psl,\n" +
                "  --    bpm.prsn_baseline_ds pb,\n" +
                "      bpm.empl_grp_site egs,\n" +
                "      bpm.business_program bp,\n" +
                "   (select distinct pb2.grp_id,\n" +
                "           pb2.subgrp_id,\n" +
                "           pb2.person_no,\n" +
                "           pb2.biz_pgm_eff_dt,\n" +
                "           row_number() over (partition by pb2.grp_id, pb2.subgrp_id, pb2.person_no order by pb2.biz_pgm_eff_dt desc) as rnk   \n" +
                "                      \n" +
                "           from bpm.prsn_baseline_ds pb2\n" +
                "           \n" +
                "           group by \n" +
                "           pb2.grp_id,\n" +
                "           pb2.subgrp_id,\n" +
                "           pb2.person_no,\n" +
                "           pb2.biz_pgm_eff_dt) pb\n" +
                "   \n" +
                " where \n" +
                "--Joins\n" +
                " psl.prsn_id = pb.person_no\n" +
                " and ((pb.grp_id = egs.grp_id) and (pb.subgrp_id = egs.subgrp_id))\n" +
                " and ((bp.grp_id = pb.grp_id) \n" +
                "       and (bp.subgrp_id = pb.subgrp_id) \n" +
                "       and (bp.eff_dt = pb.biz_pgm_eff_dt)) \n" +
                "      \n" +
                "\n" +
                "--Filters \n" +
                "and pb.rnk = 1      \n" +
                " and psl.prcsng_stat_val in ('COMPLETED')\n" +
                " --and egs.empl_grp_no in ('3190')\n" +
                " and trunc(psl.insert_ts) >= '01-jan-2023'\n" +
                " --and pb.biz_pgm_eff_dt = '01-jan-2022'\n" +
                " --and rownum < 10000\n" +
                " and bp.eff_dt >= '01-jan-2020'\n" +
                " \n" +
                " group by --psl.prsn_id,\n" +
                "          pb.grp_id,\n" +
                "          egs.empl_grp_no,\n" +
                "          egs.empl_grp_nm\n" +
                "      --      bp.biz_pgm_tp_cd,\n" +
                "      --    pb.biz_pgm_eff_dt\n" +
                "      --    pb.subgrp_id,\n" +
                "      --    egs.empl_grp_site_id_no,\n" +
                "      --    egs.empl_grp_site_nm,\n" +
                "      --    pb.rel_cd\n" +
                "         -- psl.insert_ts\n" +
                ") x\n" +
                "\n" +
                "--order by x.empl_grp_no asc, x.empl_grp_site_id_no asc, x.rel_cd asc\n" +
                "order by x.empl_grp_no asc /*, x.biz_pgm_eff_dt asc */";

        Statement stmt = connectToDB().createStatement();
        ResultSet resultSet = stmt.executeQuery(data);
        resultSet.next();
        resultSet.last();
        System.out.println(resultSet.getRow());
        System.out.println(resultSet.findColumn("EMPL_GRP_NM"));
        System.out.println(resultSet.getString("EMPL_GRP_NM"));
        return resultSet.getString("EMPL_GRP_NM");


    }

    public static String getActivitiesData() throws SQLException, ClassNotFoundException {
        String data = "select distinct pd.hp_mem_id from bpm.business_program bp,\n" + "bpm.empl_grp_site egs,\n" + " bpm.person_program_status pps,\n" + " bpm.prsn_demographics pd\n" + "where \n" + "sysdate between bp.eff_dt and bp.pgm_end_dt and\n" + "egs.empl_grp_no = '27004' and\n" + "egs.empl_grp_site_id_no = '01' and\n" + "bp.grp_id = egs.grp_id and\n" + "bp.subgrp_id = egs.subgrp_id and\n" + "bp.biz_pgm_id = pps.biz_pgm_id and\n" + "pd.prsn_id = pps.prsn_id\n";

        Statement stmt = connectToDB().createStatement();
        ResultSet resultSet = stmt.executeQuery(data);
        resultSet.next();
//        resultSet.last();
        System.out.println(resultSet.getRow());
        System.out.println(resultSet.findColumn("HP_MEM_ID"));
        System.out.println(resultSet.getString("HP_MEM_ID"));
        memberID = resultSet.getString("HP_MEM_ID");
        return memberID;

    }

    public static String getUpdate() throws SQLException, ClassNotFoundException {
        String data = "INSERT INTO ACTIVITY_EVENT_LOG (ACTV_EVNT_LOG_ID,PRCSNG_STAT_VAL,HP_MEM_ID,ACTV_ID,REGISTRATION_ID,SRCE_SYSTM_ID,AUTH_CD,STAT_CD,STAT_EFF_DT,STAT_OUTCM,INSERT_TS,MODIFY_TS,INSERT_USR,MODIFY_USR,RSN_DESC,APRV_USR_ID,APRV_DT)Values(ACTIVITY_EVENT_LOG_SEQ.NEXTVAL,'PENDING','MEMBERID','HA','50766812','5','350222','COMPLETE',to_date('02/13/2023','MM/DD/YYYY'),'NA',sysdate, sysdate,'f5929', 'tjquist',NULL,NULL,NULL )";
        data = data.replace("MEMBERID", memberID);
        System.out.println(data);
        Statement stmt = connectToDB().createStatement();
        ResultSet resultSet = stmt.executeQuery(data);
        resultSet.next();
        resultSet.last();
        System.out.println(resultSet.getRow());
        System.out.println(resultSet.findColumn("STAT_CD"));
        System.out.println(resultSet.getString("STAT_CD"));
        return resultSet.getString("STAT_CD");


    }

}



