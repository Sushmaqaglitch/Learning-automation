package com.application.bpm.ui.pages.groupsetupandmaintainance;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;

public class GroupSiteExceptions extends UIActions {

    private static By link_GroupSiteException = By.id("showGroupSiteException");
    private static By text_GroupNumber = By.id("groupNumber");
    private static By button_AddGroup = By.name("addGroupSiteException");
    private static By button_Edit = By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[1]/a");
    private static By button_Save = By.name("save");
    private static By button_Copy = By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[2]/a");
    private static By hyperLink_Remove = By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[10]/a");

    private static By dropdown_ProgramTypeName = By.id("programTypeCode");
    private static By dropdown_ExceptionType = By.id("luvExceptionTypeID");
    private static By exception_IssueDate = By.id("issueDate");
    private static By exception_Reason = By.id("exceptionReason");
    private static By exception_Approver = By.id("approverID");
    private static By effective_Date = By.id("effectiveDate");
    private static By end_Date = By.id("endDate");
    private static By saveto_SelectedSites = By.name("saveToSelected");
    private static By add_Siteno = By.xpath("//*[@id=\"tableAvailableSites\"]/tbody/tr/td[1]/a");

    public static void userPerformGroupSiteException() {
        clickOnElement(link_GroupSiteException);

    }

    public static void userPerformGroupNumber() {
        clickOnElement(text_GroupNumber);
//        enterText(text_GroupNumber, "0014");
        enterText(text_GroupNumber, "5032");
    }

    public static void verifyAddButtonStatus() {


    }

    public static void userPerformEdit() {
        clickOnElement(button_Edit);
    }

    public static void userPerformSave() {
        clickOnElement(button_Save);
    }

    public static void userPerformCopy() {
        clickOnElement(button_Copy);
    }

    public static void userPerformRemove() {
        clickOnElement(hyperLink_Remove);
    }

    public static void userPerformAdd() {
        clickOnElement(button_AddGroup);
    }

    public static void userPerformProgramTypeName() {
        clickOnElement(dropdown_ProgramTypeName);
        selectDropDownByText(dropdown_ProgramTypeName, "ISR");
    }

    public static void userPerformExceptionType() {
        clickOnElement(dropdown_ExceptionType);
        selectDropDownByText(dropdown_ExceptionType, "EXCLUDE_GRP_SITE");

    }

    public static void userPerformExceptionIssueDate() {
        clickOnElement(exception_IssueDate);
        enterText(exception_IssueDate, "09/06/2024");

    }

    public static void userPerformExceptionReason() {
        clickOnElement(exception_Reason);
        enterText(exception_Reason, "Testing By Sushma");

    }

    public static void userPerformExceptionApprover() {
        clickOnElement(exception_Approver);
        enterText(exception_Approver, "Sushma Puligandla");

    }

    public static void userPerformEffectiveDate() {
        clickOnElement(effective_Date);
        enterText(effective_Date, "09/06/2024");


    }

    public static void userPerformEndDate() {
        clickOnElement(end_Date);
        enterText(end_Date, "09/06/2024");


    }

    public static void userPerformSaveToSelected() {
        clickOnElement(saveto_SelectedSites);


    }

    public static void userPerformAddSiteNo() {
        clickOnElement(add_Siteno);

    }
}