package com.application.bpm.ui.pages.memberadministration;
public class ActivityStatusOverride {
}
