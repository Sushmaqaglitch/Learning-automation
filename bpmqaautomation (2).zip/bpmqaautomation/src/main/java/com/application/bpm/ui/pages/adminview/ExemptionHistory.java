package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.junit.Assert;
import org.openqa.selenium.By;
public class ExemptionHistory extends UIActions {
    private static By textBox_GroupNumber = By.name("groupNumber");
    private static By textBox_GroupName = By.name("groupName");
    private static By textBox_SiteNumber = By.name("siteNumber");
    private static By textBox_EffectiveDate = By.name("effectiveDate");
    private static By textBox_MemberNumber = By.name("memberNumber");
    private static By dropDown_ExemptionType = By.name("exemptionType");
    private static By link_ExemptionHistory = By.name("exemptionHistory");
    private static By textBox_ExemptionFromDate = By.name("exemptionFromDate");
    private static By textBox_ExemptionToDate = By.name("exemptionToDate");
    private static By button_Search = By.name("search");

    private static By header_Text = By.xpath("//samp[@class='altxlight']");


    public static void clickOnExemptionHistory() {
        Assert.assertTrue("Expected condition not found ", driver.findElement(link_ExemptionHistory).isDisplayed());
        clickOnElement(link_ExemptionHistory);
        Assert.assertNotEquals("Page name mismatched", "MEMBER EXEMPTION HISTORY SEARCH 234 ", getText(header_Text).trim());

    }

    public static void userPerformExemptionHistory() {
        try {
            enterText(textBox_GroupNumber, "1234");
            enterText(textBox_GroupName, "sushma");
            enterText(textBox_SiteNumber, "123");
            enterText(textBox_EffectiveDate, "10/26/2022");
            enterText(textBox_MemberNumber, "3459");
            enterText(dropDown_ExemptionType, "Manual Exemption");
            enterText(textBox_ExemptionFromDate, "10/22/2022");
            enterText(textBox_ExemptionToDate, "01/10/2022");
            clickOnElement(button_Search);
        } catch (Exception e) {
            Assert.fail("userPerformExemptionHistory method is failed ");
        }


    }
}
