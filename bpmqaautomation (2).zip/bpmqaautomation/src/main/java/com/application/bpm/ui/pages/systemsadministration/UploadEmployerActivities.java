package com.application.bpm.ui.pages.systemsadministration;

import com.application.bpm.ui.base.UIActions;
import org.junit.Assert;
import org.openqa.selenium.By;
public class UploadEmployerActivities extends UIActions {
    private static By link_UploadEmployerActivities = By.name("addEmployerActivities");
    private static By dropDown_EmployerActivity = By.name("sourceActivityID");
    private static By textBox_ActivityDate = By.name("activityStatusDate");
    private static By textBox_GroupDescription = By.name("groupDesc");
    private static By textBox_MemberId = By.name("memberID");
    private static By textBox_RigistractionId = By.name("registrationID");
    private static By button_Search = By.xpath("//input[@id='createMemberActivity']");
    private static By dropDown_EmployerGroup = By.name("groupNo");
    private static By select_File = By.name("theMemberIDDataFile");
    private static By upload_MemberIdeFile = By.name("uploadMemberIDDataFile");
    private static By upload_DataFile = By.name("uploadDataFile");
    private static By upload_Activity_Contributions = By.name("uploadActivityContributions");
    private static By choose_dataFile = By.xpath("//input[@name='theDataFile']");
    private static By mssage_Activiy = By.xpath("//li[text()='Activity Event created successfully for member ID 51368325.']");


    public static void clickOnSystemAdministration() {
        clickOnElement(link_UploadEmployerActivities);
        selectDropDownByValue(dropDown_EmployerActivity, "CSA001");
    }

    public static void userPerformUploadEmployerActivities(String ActivityMessage) {
        selectDropDownByValue(dropDown_EmployerActivity, "2170");
        enterText(textBox_ActivityDate, "03/01/2023");
//    enterText(textBox_GroupDescription,"hi");
        //        enterText(Id_memberID, getActivitiesData());
        enterText(textBox_MemberId, "51368325");
//    enterText(textBox_RigistractionId,"123");
        clickOnElement(button_Search);
        String message = getText(mssage_Activiy);
        Assert.assertEquals(ActivityMessage, message);
        System.out.print(message);
//    selectDropDownByText(dropDown_EmployerGroup,"Target");
//    clickOnElement(select_File);
//    chooseFile(upload_DataFile);
//    WebElement dataFile= driver.findElement(choose_dataFile);
//    dataFile.sendKeys("C:\\Users\\h1115\\Desktop\\Test");
//    clickOnElement(upload_DataFile);
//
//    WebElement MemberIdFile= driver.findElement(By.xpath("//input[@name='theMemberIDDataFile']"));
//    MemberIdFile.sendKeys("C:\\Users\\h1115\\Desktop\\Test");
//    clickOnElement(upload_MemberIdeFile);
//
//    WebElement ActivityFile= driver.findElement(By.xpath("//input[@name='theContributionDataFile']"));
//    ActivityFile.sendKeys("C:\\Users\\h1115\\Desktop\\Test");
//    clickOnElement(upload_Activity_Contributions);


    }
//public static void chooseFile (By locator){
//    WebElement dataFile= driver.findElement(locator);
//    dataFile.sendKeys("C:\\Users\\h1115\\Desktop\\Test");

}

