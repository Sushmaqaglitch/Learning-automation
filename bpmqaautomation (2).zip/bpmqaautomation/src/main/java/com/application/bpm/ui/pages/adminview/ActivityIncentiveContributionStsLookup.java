package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ActivityIncentiveContributionStsLookup extends UIActions {
    private static By link_ActivityIncentive = By.id("activityIncentiveContributionStatus");
    private static By textBox_GroupNumber = By.name("groupNumber");
    private static By textBox_GroupName = By.name("groupName");
    private static By textBox_SiteNumber = By.name("siteNumber");
    private static By textBox_ContractNumber = By.name("contractNumber");
    private static By textBox_MemberNumber = By.id("memberNumber");
    private static By textBox_EffectiveDate = By.name("effectiveDate");
    private static By textBox_IncentedDate = By.name("incentedDate");
    private static By dropDown_ProductType = By.name("productType");
    private static By dropDown_ReportType = By.name("reportType");
    private static By button_Search = By.id("searchButton");

    private static By text_Message = By.xpath("//span[@class='info']/ul/li");
    private static By link_groupLookup = By.xpath("//a[@name='groupLookup']");
    private static By header_Text = By.xpath("//samp[@class='altxlight']");

    public static void clickOnActivityIncentive() {
        waitForElementIsVisible(link_ActivityIncentive);
        clickOnElement(link_ActivityIncentive);
        Assert.assertEquals("Page name mismatched", "ACTIVITY INCENTIVE CONTRIBUTION STATUS LOOKUP", getText(header_Text).trim());
    }

    public static void userPerformActivityIncentiveContributionStatusLookupSearch() {
        selectDropDownByText(dropDown_ReportType, "PENDING (SYSTEM)");
        enterText(textBox_GroupNumber, "1234");
        enterText(textBox_GroupName, "sushma");
        enterText(textBox_SiteNumber, "123");
        enterText(textBox_ContractNumber, "1234");
        enterText(textBox_MemberNumber, "345");
        enterText(textBox_EffectiveDate, "10/26/2022");
        enterText(textBox_IncentedDate, "10/27/2022");
        selectDropDownByText(dropDown_ProductType, "GROUP - HRA");
        clickOnElement(button_Search);

    }

    public static void userPerformActivityIncentiveContributionStsLookupSearch(String reportType, String grpNumber, String grpName, String siteNum, String contact, String mbrNumber, String date1, String date2, String productType) {
        selectDropDownByText(dropDown_ReportType, reportType);
        enterText(textBox_GroupNumber, grpNumber);
        enterText(textBox_GroupName, grpName);
        enterText(textBox_SiteNumber, siteNum);
        enterText(textBox_ContractNumber, contact);
        enterText(textBox_MemberNumber, mbrNumber);
        enterText(textBox_EffectiveDate, date1);
        enterText(textBox_IncentedDate, date2);
        selectDropDownByText(dropDown_ProductType, productType);
        clickOnElement(button_Search);
    }

    public static void validateErrorMessage() {
        String errorMessage = getText(text_Message);
        System.out.println(errorMessage);
    }

    public static void validateAllErrorMessages() {
        List<WebElement> allElements = getWebElements(text_Message);
        if (allElements != null) {
            for (WebElement ele : allElements) {
                System.out.println(ele.getText());

            }
        }
    }

}
