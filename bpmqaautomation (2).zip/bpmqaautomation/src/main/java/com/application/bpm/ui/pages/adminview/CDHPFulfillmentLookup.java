package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.junit.Assert;
import org.openqa.selenium.By;

//import static org.junit.Assert.*;

public class CDHPFulfillmentLookup extends UIActions {
    private static By textBox_GroupNumber = By.name("groupNumber");
    private static By textBox_GroupName = By.name("groupName");
    private static By textBox_SiteNumber = By.name("siteNumber");
    private static By textBox_ContractNumber = By.name("contractNumber");
    private static By textBox_MemberNumber = By.id("memberNumber");
    private static By textBox_EffectiveDate = By.name("effectiveDate");
    private static By link_CdhpFulfilment = By.name("cdhpFulfillmentHistory");
    private static By textBox_FileSentFromDate = By.name("fileSentFromDate");
    private static By textBox_fileSentToDate = By.name("fileSentToDate");
    private static By dropDown_cdhpTableType = By.name("cdhpTableType");
    private static By dropDown_ProductType = By.name("productType");
    private static By button_Search = By.name("search");

    private static By header_Text = By.xpath("//samp[@class='altxlight']");


    public static void clickOnCdhpFulfilment() {
        clickOnElement(link_CdhpFulfilment);
        Assert.assertEquals("Page name mismatched", "CDHP FULFILLMENT CONTRIBUTION LOOKUP", getText(header_Text).trim());
    }

    public static void userPerformCdhpFulfillmentHistoryLookup() {

        enterText(textBox_GroupNumber, "1234");
        enterText(textBox_GroupName, "sushma");
        enterText(textBox_SiteNumber, "123");
        enterText(textBox_EffectiveDate, "10/26/2022");
        enterText(textBox_ContractNumber, "1234");
        enterText(textBox_MemberNumber, "345");
        enterText(textBox_FileSentFromDate, "01/20/22");
        enterText(textBox_fileSentToDate, "10/12/22");
        selectDropDownByText(dropDown_ProductType, "GROUP - HRA");
        selectDropDownByText(dropDown_cdhpTableType, "FULFILL CONTRACT");
        clickOnElement(button_Search);

    }

    public static void userPerformCdhpFulfillmentHistoryLookup(String groupNumber, String grpName, String siteNum, String effectiveDate, String contactNumber, String memberNumber, String fileSentFromDate, String fileSentToDate, String productType, String tableType) {
        enterText(textBox_GroupNumber, groupNumber);
        enterText(textBox_GroupName, grpName);
        enterText(textBox_SiteNumber, siteNum);
        enterText(textBox_EffectiveDate, effectiveDate);
        enterText(textBox_ContractNumber, contactNumber);
        enterText(textBox_MemberNumber, memberNumber);
        enterText(textBox_FileSentFromDate, fileSentFromDate);
        enterText(textBox_fileSentToDate, fileSentToDate);
        selectDropDownByText(dropDown_ProductType, productType);
        selectDropDownByText(dropDown_cdhpTableType, tableType);
        clickOnElement(button_Search);
//        assertEquals("GroupNAME IS NOT MATCHED","Sushma","rINA");
//        assertNotEquals("","");

    }
}
