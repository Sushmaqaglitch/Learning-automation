package com.application.bpm.ui.pages.groupsetupandmaintainance;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;

public class MemberContractRecycleReview extends UIActions {


    private static By link_MemberContractRecycleReview = By.id("personContractRecycleSearch");
    private static By text_GroupNumber1=By.id("groupNo");


    public static void userPerformMemberContractRecycleReview() {
        clickOnElement(link_MemberContractRecycleReview);
    }

    public static void userPerformGroupNumber() {
        clickOnElement(text_GroupNumber1);
        enterText(text_GroupNumber1, "32310");
    }
}