package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.sql.SQLException;

public class MemberStatus extends UIActions {
    private static By link_memberStatus = By.id("memberStatus");
    private static By Id_memberID = By.name("memberID");
    private static By TextBox_lastName = By.name("lastName");
    private static By TextBox_firstName = By.name("firstName");
    private static By TextBox_dateOfBirth = By.name("dateOfBirth");
    private static By button_search = By.name("search");
    private static By RelationShipType = By.xpath("//table[2]/tbody/tr[9]/td[4]");
    private static By Label_Activities = By.xpath("//td[text()='Activities - NONE']");
    private static By Activty_Log = By.xpath("//th[text()='Activity Event Log']");
    private static By Activity_Name = By.xpath("//th[text()='Activity Name']");
    private static By Processing_Status = By.xpath("//th[text()='Processing Status']");
    private static By Incentive_Status = By.xpath("//th[text()='Incentive Status']");
    private static By Contact_Status = By.xpath("//th[text()='Contract Status']");
    private static By Member_Status = By.xpath("//th[text()='Member Status']");
    private static By Contract_Incentives = By.xpath("//th[text()='Contract Incentives']");
    private static By Incentive_Option_Name = By.xpath("//th[text()='Incentive Option Name']");
    private static By Staus = By.xpath("//th[text()='Status']");
    private static By Activation_Status = By.xpath("//th[text()='Activation Status']");
    private static By link_Member_Status = By.xpath("//*[@id=\"memberStatus\"]");
    private static By member_Id = By.name("memberID");
    private static By search_Button = By.name("search");


    public static void clickOnMemberStatus() {
        clickOnElement(link_memberStatus);
    }


    public static void performMemberStatusSearch() throws SQLException, ClassNotFoundException {
//        enterText(Id_memberID, getActivitiesData());
        enterText(Id_memberID, "51368325");
        clickOnElement(button_search);
    }

    public static void verifyTheRelationshipType(String relationshipType) {

        Assert.assertEquals("Expected Relation Type is not available", relationshipType, getText(RelationShipType).split(" ")[0]);

    }

    public static void verifyTheEventActivities(String Activities) throws SQLException, ClassNotFoundException {

        if (isElementDisplayed(Label_Activities)) {
            System.out.println("Activity details not found");
            getUpdate();
            refreshPage();
            if (!isElementDisplayed(Label_Activities)) {
                System.out.println("Activity details Loaded");
            }
        } else {
            System.out.println("Activity details Exist");
        }


    }


    public static void verifyTheEventActivityLog(String Activitylog) {
//        String Actual_Activities = getText(By.xpath("//td[text()= ["+ Activities +"]]"));
        if (Activty_Log.equals(Activitylog)) {
            System.out.println(getText(Activty_Log));
//            Assert.assertEquals("Activities Already Exists", Activities, Label_Activities);
        }


    }

    public static void verifyTheActivityName(String activityName, String processingStatus) throws InterruptedException {

        int rows = driver.findElements(By.xpath("//th[text()='Activity Event Log']/../../../tbody/tr")).size();
        System.out.println(rows);
        boolean isActivityLogAvaiable = false;

        for (int r = 1; r <= rows; r++) {
            if (isElementDisplayed(By.xpath("//th[text()='Activity Event Log']/../../../tbody/tr[" + r + "]/td[2]"))) {
                String ActivityName = driver.findElement(By.xpath("//th[text()='Activity Event Log']/../../../tbody/tr[" + r + "]/td[2]")).getText();
                String ProcessingStatus = driver.findElement(By.xpath("//th[text()='Activity Event Log']/../../../tbody/tr[" + r + "]/td[8]")).getText();
                System.out.println(ActivityName);
                System.out.println(ProcessingStatus);
                Thread.sleep(40000);
                if (activityName.equalsIgnoreCase(ActivityName)) {
                    if (processingStatus.equalsIgnoreCase(ProcessingStatus)) {
                        System.out.println(ActivityName + " " + ProcessingStatus + " found at row number" + r);
                        isActivityLogAvaiable = true;
                        break;
                    }
                }
            }

        }
        if (!isActivityLogAvaiable) {
            Assert.fail("Activity is not avialvble");
        }
    }

    public static void verifyMemberPackageCodeName(String packageCode, String packageName) throws InterruptedException {
        int rows = driver.findElements(By.xpath("//th[text()='Member Packages']/../../../tbody/tr")).size();
        System.out.println(rows);
        for (int r = 1; r <= rows; r++) {
            if (isElementDisplayed(By.xpath("//th[text()='Member Packages']/../../../tbody/tr[" + r + "]/td[2]"))) {
                String PackageCode = driver.findElement(By.xpath("//th[text()='Member Packages']/../../../tbody/tr[" + r + "]/td[2]")).getText();
                String PackageName = driver.findElement(By.xpath("//th[text()='Member Packages']/../../../tbody/tr[" + r + "]/td[3]")).getText();
                System.out.println(PackageCode);
                System.out.println(PackageName);
                if (packageCode.equalsIgnoreCase(PackageCode)) {
                    if (packageName.equalsIgnoreCase(PackageName)) {
                        System.out.println(PackageCode + " " + PackageName + " found at row number" + r);
                        break;
                    }
                }
            }
        }
    }

    public static void verifyIncentiveStatus(String incentiveOption, String incentiveStatus, String memberStatus) throws InterruptedException {

        int rows = driver.findElements(By.xpath("//th[text()='Incentive Status']/../../../tbody/tr")).size();
        System.out.println(rows);
        boolean isrecordsmatched = false;
        for (int r = 1; r <= rows; r++) {
            if (isElementDisplayed(By.xpath("//th[text()='Incentive Status']/../../../tbody/tr[" + r + "]/td[1]"))) {
                String IncentiveOption = driver.findElement(By.xpath("//th[text()='Incentive Status']/../../../tbody/tr[" + r + "]/td[1]")).getText();
                String IncentiveStatus = driver.findElement(By.xpath("//th[text()='Incentive Status']/../../../tbody/tr[" + r + "]/td[3]")).getText();
                String MemberStatus = driver.findElement(By.xpath("//th[text()='Incentive Status']/../../../tbody/tr[" + r + "]/td[6]")).getText();
                System.out.println(IncentiveOption);
                System.out.println(IncentiveStatus);
                System.out.println(MemberStatus);
                if (IncentiveOption.equalsIgnoreCase(incentiveOption) && IncentiveStatus.equalsIgnoreCase(incentiveStatus) && MemberStatus.equalsIgnoreCase(memberStatus)) {
                    System.out.println(IncentiveOption + " " + IncentiveStatus + " " + MemberStatus + " Members are found at row number " + r);
                    isrecordsmatched = true;
                    break;
                }


            }

        }
    }

    public static void verifyMemberIncentives(String incentiveOptionName, String incentivesAchievedStatus, String activationStatus) throws InterruptedException {

        int rows = driver.findElements(By.xpath("//th[text()='Member Incentives']/../../../tbody/tr")).size();
        System.out.println(rows);
        boolean isrecordsmatched = false;
        for (int r = 1; r <= rows; r++) {
            if (isElementDisplayed(By.xpath("//th[text()='Member Incentives']/../../../tbody/tr[" + r + "]/td[1]"))) {
                String IncentiveOptionName = driver.findElement(By.xpath("//th[text()='Member Incentives']/../../../tbody/tr[" + r + "]/td[1]")).getText();
                String IncentivesAchievedStatus = driver.findElement(By.xpath("//th[text()='Member Incentives']/../../../tbody/tr[" + r + "]/td[2]")).getText();
                String ActivationStatus = driver.findElement(By.xpath("//th[text()='Member Incentives']/../../../tbody/tr[" + r + "]/td[4]")).getText();
                System.out.println(IncentiveOptionName);
                System.out.println(IncentivesAchievedStatus);
                System.out.println(ActivationStatus);
                if (IncentiveOptionName.equalsIgnoreCase(incentiveOptionName) && IncentivesAchievedStatus.equalsIgnoreCase(incentivesAchievedStatus) && ActivationStatus.equalsIgnoreCase(activationStatus)) {
                    System.out.println(IncentiveOptionName + " " + IncentivesAchievedStatus + " " + ActivationStatus + " Members are found at row number " + r);
                    isrecordsmatched = true;
                    break;
                }
            }
        }
    }

    public static void verifyContractIncentives(String incentiveoptionName, String incentivesachievedStatus, String activationstatus) throws InterruptedException {

        int rows1 = driver.findElements(By.xpath("//th[text()='Contract Incentives']/../../../tbody/tr")).size();
        System.out.println(rows1);
        boolean isrecordsmatched = false;
        for (int r = 1; r <= rows1; r++) {
            if (isElementDisplayed(By.xpath("//th[text()='Contract Incentives']/../../../tbody/tr[" + r + "]/td[1]"))) {
                String IncentiveOptionName1 = driver.findElement(By.xpath("//th[text()='Contract Incentives']/../../../tbody/tr[" + r + "]/td[2]")).getText();
                String IncentivesAchievedStatus2 = driver.findElement(By.xpath("//th[text()='Contract Incentives']/../../../tbody/tr[" + r + "]/td[3]")).getText();
                String ActivationStatus3 = driver.findElement(By.xpath("//th[text()='Contract Incentives']/../../../tbody/tr[" + r + "]/td[5]")).getText();
                System.out.println(IncentiveOptionName1);
                System.out.println(IncentivesAchievedStatus2);
                System.out.println(ActivationStatus3);
                if (IncentiveOptionName1.equalsIgnoreCase(incentiveoptionName) && IncentivesAchievedStatus2.equalsIgnoreCase(incentivesachievedStatus) && ActivationStatus3.equalsIgnoreCase(activationstatus)) {
                    System.out.println(IncentiveOptionName1 + " " + IncentivesAchievedStatus2 + " " + ActivationStatus3 + " Members are found at row number " + r);
                    isrecordsmatched = true;
                    break;
                }


            }

        }
    }

    public static void verifyMemberProgramActivities(String activityName, String activityStatus) throws InterruptedException {

        int rows1 = driver.findElements(By.xpath("//th[text()='Member Program Activities']/../../../tbody/tr")).size();
        System.out.println(rows1);
        boolean isrecordsmatched = false;
        for (int r = 1; r <= rows1; r++) {
            if (isElementDisplayed(By.xpath("//th[text()='Member Program Activities']/../../../tbody/tr[" + r + "]/td[1]"))) {
//                String IncentiveOptionName1 = driver.findElement(By.xpath("//th[text()='Member Program Activities']/../../../tbody/tr[" + r + "]/td[2]")).getText();
                String ActivityName = driver.findElement(By.xpath("//th[text()='Member Program Activities']/../../../tbody/tr[" + r + "]/td[2]")).getText();
                String ActivityStatus = driver.findElement(By.xpath("//th[text()='Member Program Activities']/../../../tbody/tr[" + r + "]/td[4]")).getText();
                System.out.println(ActivityName);
                System.out.println(ActivityStatus);
//                System.out.println(ActivationStatus3);
                if (ActivityName.equalsIgnoreCase(activityName) && ActivityStatus.equalsIgnoreCase(activityStatus)) {
                    System.out.println(ActivityName + " " + ActivityStatus + " " + " Members are found at row number " + r);
                    isrecordsmatched = true;
                    break;
                }


            }

        }
    }

      /* if (Activity_Name.equals(Activityname)) {
            System.out.println(getText(Activity_Name));
//            Assert.assertEquals("Activities Already Exists", Activities, Label_Activities);
        }*/


    public static void verifyTheProcessingStatus(String Processingstatus) {
//        String Actual_Activities = getText(By.xpath("//td[text()= ["+ Activities +"]]"));
        if (Processing_Status.equals(Processingstatus)) {
            System.out.println(getText(Processing_Status));
//            Assert.assertEquals("Activities Already Exists", Activities, Label_Activities);
        }
    }

    public static void verifyTheIncentiveStatus(String Incentivestatus) {
//        String Actual_Activities = getText(By.xpath("//td[text()= ["+ Activities +"]]"));
        if (Incentive_Status.equals(Incentivestatus)) {
            System.out.println(getText(Incentive_Status));
//            Assert.assertEquals("Activities Already Exists", Activities, Label_Activities);
        }
    }

    public static void verifyTheContractStatus(String Contractstatus) {
//        String Actual_Activities = getText(By.xpath("//td[text()= ["+ Activities +"]]"));
        if (Contact_Status.equals(Contractstatus)) {
            System.out.println(getText(Contact_Status));
//            Assert.assertEquals("Activities Already Exists", Activities, Label_Activities);
        }
    }

    public static void verifyTheMemberStatus(String Memberstatus) {
//        String Actual_Activities = getText(By.xpath("//td[text()= ["+ Activities +"]]"));
        if (Member_Status.equals(Memberstatus)) {
            System.out.println(getText(Member_Status));
//            Assert.assertEquals("Activities Already Exists", Activities, Label_Activities);
        }
    }

    public static void verifyTheContractIncentives(String Contractincentives) {
//        String Actual_Activities = getText(By.xpath("//td[text()= ["+ Activities +"]]"));
        if (Contract_Incentives.equals(Contractincentives)) {
            System.out.println(getText(Contract_Incentives));
//            Assert.assertEquals("Activities Already Exists", Activities, Label_Activities);
        }
    }

    public static void verifyTheIncentiveOptionName(String Incentiveoptionname) {
//        String Actual_Activities = getText(By.xpath("//td[text()= ["+ Activities +"]]"));
        if (Incentive_Option_Name.equals(Incentiveoptionname)) {
            System.out.println(getText(Incentive_Option_Name));
//            Assert.assertEquals("Activities Already Exists", Activities, Label_Activities);
        }
    }

    public static void verifyTheStatus(String Status) {
//        String Actual_Activities = getText(By.xpath("//td[text()= ["+ Activities +"]]"));
        if (Staus.equals(Status)) {
            System.out.println(getText(Staus));
//            Assert.assertEquals("Activities Already Exists", Activities, Label_Activities);
        }
    }

    public static void verifyTheActivationStatus(String Activationstatus) {
//        String Actual_Activities = getText(By.xpath("//td[text()= ["+ Activities +"]]"));
        if (Activation_Status.equals(Activationstatus)) {
            System.out.println(getText(Activation_Status));
//            Assert.assertEquals("Activities Already Exists", Activities, Label_Activities);
        }
    }

    public static void UserClickOnMemberStatus() {
        clickOnElement(link_Member_Status);

    }

    public static void userEnterMemberId() {
        clickOnElement(member_Id);
        enterText(member_Id, "12646488");
    }

    public static void userPerformSearch() {
        clickOnElement(search_Button);
    }
}



