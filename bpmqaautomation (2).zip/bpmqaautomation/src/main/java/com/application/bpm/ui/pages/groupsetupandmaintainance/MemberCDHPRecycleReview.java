package com.application.bpm.ui.pages.groupsetupandmaintainance;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;

public class MemberCDHPRecycleReview extends UIActions {

    private static By link_MemberCDHPRecycleReview = By.id("personCDHPFulfillRecycleSearch");
    private static By text_GroupNumber = By.id("groupNo");

    private static By link_Edit=By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[3]/a");
    private static By text_Approver=By.id("approver");
    private static By text_Reason=By.id("reason");
    private static By button_Save1=By.className("button");
    private static By button_Back=By.name("back");
    private static By check_Mark=By.id("selectedRecycleIDs");




    public static void userPerformMemberCDHPRecycleReview() {
        clickOnElement(link_MemberCDHPRecycleReview);
    }
    public static void userPerformGroupNumber() {
        clickOnElement(text_GroupNumber);
        enterText(text_GroupNumber, "3052");

}

    public static void userPerformEdit() {
        clickOnElement(link_Edit);
}
    public static void userPerformApprovername() {
        clickOnElement(text_Approver);
        enterText(text_Approver, "h1115");
}
    public static void userPerformApproverReason() {
        clickOnElement(text_Reason);
        enterText(text_Reason, "Testing");

}
    public static void userPerformSave1() {
        clickOnElement(button_Save1);

}
    public static void userPerformBackButton() {
        clickOnElement(button_Back);


}
    public static void userPerformClickonCheckMark() {
        clickOnElement(check_Mark);

}}