package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;

public class AdditionalProgramInfo extends UIActions {


    private static By button_additional_Program_Info = By.name("editAdditionalInfo");
    private static By button_Add2 = By.name("addFreeForm");
    private static By text_Program_Additional_info = By.name("additionalInfoNames[3]");
    private static By text_Additional_Info_Text = By.name("additionalInfoTexts[3]");
    private static By button_Save = By.name("save");
    private static By button_Remove = By.xpath("//*[@id=\"tableAdditionalInfos\"]/thead/tr[2]/td[1]/a");
    private static By button_SaveToAllSites = By.name("saveToAllSites");
    private static By button_SavetoSelectedSites = By.name("saveToSelectedSites");


    public static void userPerformAdditionalProgramInfo() {
        clickOnElement(button_additional_Program_Info);
    }

    public static void userPerformAddButton2() {
        clickOnElement(button_Add2);
    }

    public static void userPerformProgramAdditionalInfoNames() {
        clickOnElement(text_Program_Additional_info);
        enterText(text_Program_Additional_info, "Test");
    }

    public static void userPerformAdditionalInfoText() {
//        clickOnElement(text_Additional_Info_Text);
        enterText(text_Additional_Info_Text, "Testing");
    }

    public static void userPerformSave() {
        clickOnElement(button_Save);
    }

    public static void userPerformRemove() {
        clickOnElement(button_Remove);

    }

    public static void userPerformSavetoAllSites() {
        clickOnElement(button_SaveToAllSites);
    }


}
