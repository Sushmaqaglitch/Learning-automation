package runner;

import com.intuit.karate.KarateOptions;
import com.intuit.karate.junit4.Karate;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
@RunWith(Karate.class)

//@KarateOptions(features = "classpath:features/api_testcases", tags = "@SMOKE")
@KarateOptions(features = "classpath:features/ui_testcases/", tags = "@Activity")
public class TestRunner {
    @BeforeClass
    public static void runBeforeClass() {
        System.setProperty("karate.env", "test");
    }
}
