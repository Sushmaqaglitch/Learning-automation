function fn() {

// all common config parameters set here
    karate.configure('connectTimeout', 200000);
    karate.configure('readTimeout', 200000);
    karate.configure('ssl', true);
// set your environment before you run tes

    //var environment = karate.env
    var environment = 'dev'
    karate.log('karate environment property was:', environment);

    var config = {
        bpmApplicationURL: '',
        bpmApplicationUserName: '',
        bpmApplicationPassword: '',
        apiBaseURI: 'https://some-host.com/v1/auth/',
        apiUserName: '',
        apiUserPassword: '',
        dbUrl: '',
        dbUserName: '',
        dbPassword: ''
    };
    // set application , api and db information here based on your environment
    if (environment == 'test') {
        config.bpmApplicationURL = 'https://bpmtest.healthpartners.com/bpm-admin/bpmadminindex.do;'
        config.bpmApplicationUserName = 'h1115';
        config.bpmApplicationPassword = 'Pulisush@7077';
        config.apiBaseURI = 'https://admin-imfs-bpm.apps.uat-int.ocp.healthpartners.com/api';
        config.apiUserName = 'apiUserName';
        config.apiUserPassword = 'apiUserPassword';
        config.dbUrl = 'jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=oradevrac.healthpartners.com)(PORT=1551))(CONNECT_DATA=(SERVICE_NAME=bpmtst.healthpartners.com)))';
        config.dbUserName = 'h1115';
        config.dbPassword = 'Pulisush@7077';
    } else if (environment == 'dev') {
        config.bpmApplicationURL = 'https://accessible.apps.dev2-int.ocp.healthpartners.com/bpm-admin';
        //'https://bpmdev.healthpartners.com/bpm-admin/bpmadminindex.do';
        config.bpmApplicationUserName = 'h1115';
        config.bpmApplicationPassword = 'Pulisush@7077';
        config.apiBaseURI = 'https://admin-imfs-bpm.apps.dev2-int.ocp.healthpartners.com/api';
        config.apiUserName = 'apiUserName';
        config.apiUserPassword = 'apiUserPassword';
        config.dbUrl = 'jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=oradevrac.healthpartners.com)(PORT=1551))(CONNECT_DATA=(SERVICE_NAME=bpmdvl.healthpartners.com)))';
        config.dbUserName = 'h1115';
        config.dbPassword = 'Pulisush@7077';
    }
    return config;
}


