package com.application.bpm.ui.pages.groupsetupandmaintainance;

import com.application.bpm.ui.base.UIActions;
import org.junit.Assert;
import org.openqa.selenium.By;

public class Activity extends UIActions {
    private static By Link_Activity = By.name("Activity");
    private static By button_action = By.name("action");
    private static By text_SourceSystemId = By.id("sourceSystemID");
    private static By text_ActivityName =By.id("activityName");
    private static By text_Duration =By.id("activityDuration");
    private static By text_HostSource =By.id("hostSource");
    private static By textBox_EffectiveDate=By.id("effDate");
    private static By dropDown_ActivityType=By.id ("luvActivityTypeCodeId");
    private static By text_Cost=By.id ("cost");
    private static By textBox_EndDate =By.id ("endDate");
    private static By text_Description = By.xpath("//textarea[@id='description']");
    private static By dropDownValue=By.xpath("getSelectedDropdownValue");
    private static By button_Save = By.xpath("//input[@value='Save']");


//   private static By message_help=By.xpath("//table/tbody/tr/td/table[2]/tbody/tr/td/table/tbody/tr/td[2]/div/table/tbody/tr/td/span/ul/li/text()");
   //String Help_Message=getText(message_help);
    private static By Help=By.xpath("//*[@id=\"content\"]/table/tbody/tr/td/table[2]/tbody/tr/td/table/tbody/tr/td[2]/div/table/tbody/tr/td/strong\n");
    public static void userDeleteOnTheActivity() {
        clickOnElement(Link_Activity);
//        Assert.assertEquals("Page name mismatched", "CDHP FULFILLMENT CONTRIBUTION LOOKUP", getText(header_Text).trim());
        if(isElementDisplayed(Help)){
          By message_help=By.xpath("//span/ul/li");
           String Help_Message=getText(message_help);
            System.out.println(Help_Message);

           String help_message="An activity record can not be deleted if used in Business Programs.";
           if (Help_Message.equalsIgnoreCase(help_message)){
                System.out.println("help Message displayed successfully: "+Help_Message);
            }
           else {
               System.out.println("Incorrect help Message displayed: "+Help_Message);
            }
        }
    }
    public static void userClickOnTheAdd(){
        clickOnElement(Link_Activity);
        clickOnElement(button_action);
        enterText(text_SourceSystemId, "15k");
        enterText(text_ActivityName, "Health");
        enterText(text_Duration,"0" );
        enterText(text_HostSource, "vendor");
        enterText(textBox_EffectiveDate, "02/03/2024");
        clickOnElement(dropDown_ActivityType);
        selectDropDownByText(dropDown_ActivityType,"Online Course");
        enterText(text_Cost, "1.00");
        enterText(textBox_EndDate, "02/10/2024");
        enterText(text_Description, "Hello");
        clickOnElement(button_Save);


    }
//    public static void userClickOnSourceSystemActivityID(){
//        clickOnElement(text_SourceSystemId);


    }
//    public static void userClickOnActivityName(){
//        clickOnElement(text_ActivityName);

//}
//    public static void userClickOnDuration(){
//        clickOnElement(text_Duration);
//}
//    public static void userClickOnHostSource(){
//        clickOnElement(text_HostSource);
//}
//    public static void userClickOnEffectiveDate(){
//        clickOnElement(textBox_EffectiveDate);
//
//}

//    public static void userClickOnActivityType(){
//        clickOnElement(dropDown_ActivityType);
//
//}
//
//    public static void userClickOnCost(){
//        clickOnElement(text_Cost);
//
//}
//    public static void userClickOnEndDate(){
//        clickOnElement(textBox_EndDate);


//}
//    public static void userClickOnDescription (){
//        clickOnElement(text_Description );
//
//}
//    public static void clickOnActivity() {
//        clickOnElement(Link_Activity);
//        Assert.assertEquals("Page name mismatched", "ACTIVITY", getText(header_Text).trim());
//    }
//
//    public static void userPerformActivity() {
//
//        enterText(text_SourceSystemId, "15k");
//        enterText(text_ActivityName, "health");
//        enterText(text_Duration, "0");
//        enterText(text_HostSource, "vendor");
//        enterText(textBox_EffectiveDate, "12/03/2023");
//        selectDropDownByText(dropDown_ActivityType, "online course");
//        enterText(text_Cost, "10");
//        enterText(textBox_EndDate, "12/25/23");
//        enterText(text_Description, "Hello");
//
////        selectDropDownByText(dropDown_cdhpTableType, "FULFILL CONTRACT");
////        clickOnElement(button_Search);








