package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.junit.Assert;
import org.openqa.selenium.By;

public class GroupProgramSearch extends UIActions {
    private static By textBox_GroupNumber = By.name("groupNumber");
    private static By textBox_GroupName = By.name("groupName");
    private static By button_Search = By.name("search");
    private static By link_GroupProgramSearch = By.id("programSearch");
    private static By add_Button = By.name("addProgram");
//    private static By group_Number =By.name("groupNumber");
    private static By search_Button =By.id("searchButton");
    private static By link_GroupNumber = By.xpath("//a[text()='5032']");
    private static By link_GroupStartDate =By.name("groupStartDate");
    private static By create_Program = By.id("createProgramButton");
    private static By dropdown_ProgramStatus= By.name("programStatusCodeID");
    private static By dropdown_ParticipationRequirement = By.name("familyParticipationRequirement");
    private static By button_Save = By.className("button");
    private static By button_Copy = By.xpath("//a[text()='Copy'][1]");
    private static By dropdown_SiteName=By.name("subgroupID");

    private static By text_Result = By.xpath("//td[contains(text(),'Results returned')]");
    private static By button_Delete = By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[14]/a");
    private static By button_CopyToYear =By.name("copyToYear");
    private static By text_NewStartDate = By.name("groupStartDates");
    public static By button_CheckboxCopy =By.name("selectedSubgroups");
    public static By dropdown_ProgramType = By.name ("businessProgramTypeName");
    public static By display_Message = By.xpath("//li[text()='Programs copied successfully.']");
    public static By view_Edit =By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[2]/a");
    public static By edit_Button = By.name("edit");
    public static By additional_Programinfo =By.id("additionalGroupProgramInfo");
    public static By save_AllSites=By.name("saveToAllSites");
    public static By saveToSelected_Sites=By.name("saveToSelected");
    public static By remove_Button=By.xpath("//a[text()='Remove']");
    public static By cancel_Button=By.name("cancelViewProgram");
    public static By view_Edit1 =By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[2]/td[2]/a");


    public static void clickOnGroupProgramSearch() {
        clickOnElement(link_GroupProgramSearch);
    }

    public static void userPerformGroupProgramSearch() {
        enterText(textBox_GroupNumber, "34069");
//        enterText(textBox_GroupName, "sushma");
        clickOnElement(search_Button);
    }

//    public static void userPerformGroupProgramSearch(String groupNumber, String grpName) {
//        enterText(textBox_GroupNumber, groupNumber);
//        enterText(textBox_GroupName, grpName);
//        clickOnElement(button_Search);

//    }

    public static void userPerformAddButton(){
        clickOnElement(add_Button);


//    }
//    public static void userPerformGroupNumber(){
//        clickOnElement(group_Number);
    }
    public static void userPerformSearchButton(){
        clickOnElement(search_Button);


    }
    public static void userPerformClickOnGroupNumber(){
        clickOnElement(link_GroupNumber);
    }
    public static void userPerformGroupStartDate(){
        clickOnElement(link_GroupStartDate);
        enterText(link_GroupStartDate,"01/26/2024");


    }
    public static void userPerformCreateProgram(){
        clickOnElement(create_Program);

    }
    public static void userPerformProgramStatus(){
        clickOnElement(dropdown_ProgramStatus);
        selectDropDownByText(dropdown_ProgramStatus,"Active Business Program");

    }
    public static void userPerformParticipationrequirement(){
        clickOnElement(dropdown_ParticipationRequirement);
        selectDropDownByText(dropdown_ParticipationRequirement,"All Members 18 and Older");

    }

    public static void userPerformSaveButton(){
        clickOnElement(button_Save);
    }
    public static void userPerformButton(){
        clickOnElement(button_Copy);
    }
    public static void userPerformSiteName() {
        clickOnElement(dropdown_SiteName);
    }
    public static void userPerformDelete() {
        clickOnElement(button_Delete);
    }
    public static void userPerformCopytoYear(){
        clickOnElement(button_CopyToYear);
    }
    public static void userPerformNewStartDate() {
        clickOnElement(text_NewStartDate);
        enterText(text_NewStartDate, "10/26/2024");
    }
    public static void userPerformbutton_CheckboxCopy(){
        clickOnElement(button_CheckboxCopy);
    }
    public static void userPerformdropdown_ProgramType() {
        clickOnElement(dropdown_ProgramType);
        selectDropDownByText(dropdown_ProgramType, "ISR");
    }
    public static void addedRecordValidation(){
        getElementTextByAttribute(display_Message,"Programs copied successfully.");
        System.out.println(getText(display_Message));
    }
    public static void userPerformViewEdit(){
        clickOnElement(view_Edit);
    }
    public static void userPerformEdit() {
        clickOnElement(edit_Button);
    }
    public static void userEntertheTextApi(){
        enterText(additional_Programinfo,"Testing 26272");
    }
    public static void userPerformSavetoAllSites() {
        clickOnElement(save_AllSites);
    }
    public static void userPerformSavetoSelectedSites() {
        clickOnElement(saveToSelected_Sites);
    }
    public static void userPerformRemove() {
        clickOnElement(remove_Button);
    }
    public static void userPerformCancel() {
        clickOnElement(cancel_Button);
    }
    public static void userPerformViewEdit1(){
        clickOnElement(view_Edit1);
    }




    public static void verifyGroupNameAndGroupNumberInProgramResultsGrid(String expectedGroupNumber, String expectedGrpName) {


        int totalNumberOfRows = Integer.parseInt(getText(text_Result).split("=")[1].trim());
        System.out.println("Numbers of records found :" + totalNumberOfRows);
        if (!expectedGroupNumber.isEmpty()) {
            for (int row = 2; row <= totalNumberOfRows + 1; row++) {
                String actualGroupNbr = getText(By.xpath("(//table[contains(@id,'table')]//tr)[" + row + "]/td[4]"));
                Assert.assertEquals("Group Number Not Matched", expectedGroupNumber, actualGroupNbr);
            }
        }
        if (!expectedGrpName.isEmpty()) {
            for (int row = 2; row <= totalNumberOfRows + 1; row++) {
                String actualGroupName = getText(By.xpath("(//table[contains(@id,'table')]//tr)[" + row + "]/td[3]"));
                Assert.assertEquals("Group Name Not Matched", expectedGrpName, actualGroupName);
            }
        }
    }
}
