package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.junit.Assert;
import org.openqa.selenium.By;

public class GroupLookup extends UIActions {

    private static By textBox_GroupNumber = By.id("groupNumber");
    private static By textBox_GroupName = By.id("groupName");
    private static By button_Search = By.className("button");
//    private static By add_Button = By.name("addProgram");
//    private static By group_Number =By.name("groupNumber");
//    private static By search_Button =By.id("searchButton");
//    private static By link_GroupStartDate =By.name("groupStartDate");
//    private static By create_Program = By.id("createProgramButton");
//    private static By dropdown_ProgramStatus= By.name("programStatusCodeID");
//    private static By dropdown_ParticipationRequirement = By.name("familyParticipationRequirement");
//

    private static By link_GroupLookup = By.id("groupLookup");
    private static By text_Result = By.xpath("//td[contains(text(),'Results returned')]");
    private static By link_GroupNumber = By.xpath("//*[@id=\"tablePrograms\"]/tbody/tr[1]/td[2]");
    private static By link_GroupNumber1 = By.xpath("(//*[@id=\"tableGroups\"]/tbody/tr/td[2]/a)");

    public static void clickOnGroupLookup() {
        clickOnElement(link_GroupLookup);
    }

    public static void userPerformGroupNumber() {
       enterText(textBox_GroupNumber, "3052");
        clickOnElement(button_Search);


    }
    public static void userPerformGroupName() {
        enterText(textBox_GroupName, "FEDERAL EMPLOYEES - FEHB");
        clickOnElement(button_Search);


    }
    public static void userClickOnGroupNumber(){
        waitForElementIsVisible(link_GroupNumber);
        clickOnElement(link_GroupNumber);

    }
    public static void userClickOnGroupNumberFromResults(){
        waitForElementIsVisible(link_GroupNumber1);
        clickOnElement(link_GroupNumber1);

    }
    public static void userPerformGroupLookup(String groupNumber, String grpName) {
        enterText(textBox_GroupNumber, groupNumber);
        enterText(textBox_GroupName, grpName);
        clickOnElement(button_Search);
        Assert.assertTrue("Records Results Not Found", isElementDisplayed(text_Result));
    }

    public static void verifyGroupNameAndGroupNumberInResultGrid(String expectedGroupNumber, String expectedGrpName) {


        int totalNumberOfRows = Integer.parseInt(getText(text_Result).split("=")[1].trim());
        System.out.println("Numbers of records found :" + totalNumberOfRows);
        if (!expectedGroupNumber.isEmpty()) {
            for (int row = 2; row <= totalNumberOfRows + 1; row++) {
                String actualGroupNbr = getText(By.xpath("(//table[contains(@id,'table')]//tr)[" + row + "]/td[2]"));
                Assert.assertEquals("Group Number Not Matched", expectedGroupNumber, actualGroupNbr);
            }
        }
        if (!expectedGrpName.isEmpty()) {
            for (int row = 2; row <= totalNumberOfRows + 1; row++) {
                String actualGroupName = getText(By.xpath("(//table[contains(@id,'table')]//tr)[" + row + "]/td[3]"));
                Assert.assertEquals("Group Name Not Matched", expectedGrpName, actualGroupName);
            }
        }
    }
}
