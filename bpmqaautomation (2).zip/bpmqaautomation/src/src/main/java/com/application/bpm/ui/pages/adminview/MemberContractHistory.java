package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;
public class MemberContractHistory extends UIActions {
    private static By link_MemberContractHistory = By.name("memberContractHistory");

    public static void clickOnMemberContractHistory() {
        clickOnElement(link_MemberContractHistory);
    }
}
