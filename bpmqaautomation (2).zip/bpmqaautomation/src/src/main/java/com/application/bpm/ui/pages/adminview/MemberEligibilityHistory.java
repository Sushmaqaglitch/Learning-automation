package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;
public class MemberEligibilityHistory extends UIActions {
    private static By link_MemberEligibilityHistory = By.name("baselineHistory");

    public static void clickOnMemberEligibilityHistory() {
        clickOnElement(link_MemberEligibilityHistory);
    }
}
