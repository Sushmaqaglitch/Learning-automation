package com.application.bpm.ui.pages.login;

import com.application.bpm.ui.base.PropertyReader;
import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;

public class LogIn extends UIActions {
    private static By textBox_Username = By.name("username");
    private static By textBox_Password = By.name("password");
    private static By button_Go = By.name("action");
    private static By button_Logout = By.name("Log Out");
    public static void userLoginToBPMApplication() throws Exception {
//        openChromeBrowser();

        openEdgeBrowser();
        PropertyReader pr = new PropertyReader();

//        rwebDriver();
//        Thread.sleep(3000);
        implicityWaitForPageLoad();
    openURL("https://accessible.apps.dev2-int.ocp.healthpartners.com/bpm-admin");
//        System.out.println(getPageTitle());
        enterText(textBox_Username, uiUserName);
        enterText(textBox_Password, uiPassword);
        clickOnElement(button_Go);
    }
    public static void userLogOutToBPMApplication() throws Exception {
        clickOnElement(button_Logout);
        closeChromeBrowser();
    }
}