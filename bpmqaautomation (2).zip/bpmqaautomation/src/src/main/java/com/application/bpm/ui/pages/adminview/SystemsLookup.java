package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;
public class SystemsLookup extends UIActions {
    private static By link_SystemsLookup = By.linkText("Systems Lookup");

    public static void clickOnSystemsLookup() {
        clickOnElement(link_SystemsLookup);
    }
}
