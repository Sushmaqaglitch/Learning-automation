package com.application.bpm.ui.pages.adminview;

import com.application.bpm.ui.base.UIActions;
import org.openqa.selenium.By;
public class PersonRewardCardFulfillmentLookup extends UIActions {
    private static By link_PersonRewardCardFulfillmentLookup = By.name("rewardCardFulfillmentHistory");

    public static void clickOnPersonRewardCardFulfillmentLookup() {
        clickOnElement(link_PersonRewardCardFulfillmentLookup);
    }
}
